# Noornama

A reading-room of Sufi poetry, sant vani, qawwali kalam, and the old stories.

## Deploy on Vercel

This project is already wired for Vercel (Nitro `vercel` output).

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/amjadhussainrsmp-byte/noornama&project-name=noornama&repository-name=noornama)

Or:

1. Open [Vercel](https://vercel.com/new) and sign in with GitHub.
2. Import **`amjadhussainrsmp-byte/noornama`**.
3. Leave the build command as `npm run build`.
4. Deploy. You get a `*.vercel.app` URL.
5. **Settings → Domains** to attach a domain you own.

No environment variables are required. Saved verses stay in the visitor’s browser.

## Local

```sh
npm install
npm run dev
```
