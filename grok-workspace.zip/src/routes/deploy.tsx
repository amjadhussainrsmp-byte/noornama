import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageHead } from "@/components/site-shell";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/deploy")({ component: DeployPage });

function DeployPage() {
  return (
    <main className="mx-auto max-w-2xl px-4 pb-16">
      <PageHead
        kicker="Go live"
        title="Deploy to Vercel"
        dek="Two ways to put Noornama on the open internet. Both land on Vercel’s network."
      />
      <div className="space-y-4">
        <article className="rounded-xl bg-primary p-6 text-primary-fg md:p-8">
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-primary-fg/70">Ready now</p>
          <h2 className="mt-2 font-display text-3xl">Publish from this chat</h2>
          <p className="mt-3 leading-relaxed text-primary-fg/80">
            Use <strong className="font-medium text-primary-fg">Publish</strong> in the Grok bar.
            That ships this library to Vercel and gives you a live{" "}
            <span className="text-primary-fg">grok.me</span> address. Attach a domain you already
            own from the project settings after it is live.
          </p>
        </article>
        <article className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-8">
          <p className="text-xs font-medium uppercase tracking-[0.22em] text-subtle">Your account</p>
          <h2 className="mt-2 font-display text-3xl">Your GitHub repo is ready</h2>
          <p className="mt-3 leading-relaxed text-muted">
            <a
              href="https://github.com/amjadhussainrsmp-byte/noornama"
              className="text-primary underline-offset-4 hover:underline"
              target="_blank"
              rel="noreferrer"
            >
              amjadhussainrsmp-byte/noornama
            </a>{" "}
            exists, but it is still empty. GitHub is connected here with read-only access, so the
            source cannot be pushed yet.
          </p>
          <ol className="mt-3 list-decimal space-y-2 pl-5 leading-relaxed text-muted">
            <li>Reconnect GitHub in Grok and grant repository write access.</li>
            <li>Come back and say “push it” — the site will be written into that repo.</li>
            <li>
              Import it at Vercel, leave the build command as{" "}
              <span className="font-medium text-fg">npm run build</span>, and deploy.
            </li>
          </ol>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild>
              <a href="https://github.com/amjadhussainrsmp-byte/noornama" target="_blank" rel="noreferrer">
                Open the repo
                <ArrowUpRight className="size-4" />
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href="https://vercel.com/new" target="_blank" rel="noreferrer">
                Open Vercel
                <ArrowUpRight className="size-4" />
              </a>
            </Button>
          </div>
        </article>
        <p className="text-sm text-muted">
          No secrets to set. After it is live,{" "}
          <Link to="/about" className="text-primary underline-offset-4 hover:underline">
            read about the room
          </Link>
          .
        </p>
      </div>
    </main>
  );
}
